import base64
from django.conf import settings

def generate_password(date):
    date_to_encode = settings.BUSINESS_SHORT_CODE + settings.LIPANAMPESA_PASSKEY + date 
    encode_string = base64.b64encode(date_to_encode.encode())
    decode_pass = encode_string.decode("utf-8")
    return decode_pass